package org.eclipse.core.runtime;

public class PlatformObject {

}
