package org.eclipse.core.runtime;

public class CoreException extends Exception{

}
