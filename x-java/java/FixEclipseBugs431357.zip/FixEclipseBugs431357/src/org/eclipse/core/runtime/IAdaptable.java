package org.eclipse.core.runtime;

public interface IAdaptable {

}
