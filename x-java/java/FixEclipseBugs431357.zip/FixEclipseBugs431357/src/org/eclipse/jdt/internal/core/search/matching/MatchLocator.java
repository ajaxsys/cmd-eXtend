package org.eclipse.jdt.internal.core.search.matching;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.search.MethodReferenceMatch;
import org.eclipse.jdt.core.search.SearchMatch;
import org.eclipse.jdt.core.search.SearchParticipant;
import org.eclipse.jdt.internal.compiler.ast.ASTNode;
import org.eclipse.jdt.internal.compiler.ast.MessageSend;
import org.eclipse.jdt.internal.compiler.ast.TypeReference;
import org.eclipse.jdt.internal.compiler.env.AccessRestriction;
import org.eclipse.jdt.internal.compiler.env.IBinaryType;
import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
import org.eclipse.jdt.internal.compiler.env.ISourceType;
import org.eclipse.jdt.internal.compiler.impl.ITypeRequestor;
import org.eclipse.jdt.internal.compiler.lookup.Binding;
import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
import org.eclipse.jdt.internal.core.ClassFile;

public class MatchLocator
    implements ITypeRequestor
{
	public IProgressMonitor progressMonitor;

	public void accept(ICompilationUnit arg0, AccessRestriction arg1) {
		// TODO 自動生成されたメソッド・スタブ

	}

	public void accept(IBinaryType arg0, PackageBinding arg1,
			AccessRestriction arg2) {
		// TODO 自動生成されたメソッド・スタブ

	}

	public void accept(ISourceType[] arg0, PackageBinding arg1,
			AccessRestriction arg2) {
		// TODO 自動生成されたメソッド・スタブ

	}

	public MethodReferenceMatch newMethodReferenceMatch(IJavaElement element,
			Binding elementBinding, int accuracy, int i, int j, boolean b,
			boolean c, ASTNode reference) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	public void report(SearchMatch match) {
		// TODO 自動生成されたメソッド・スタブ

	}

	public void reportAccurateParameterizedMethodReference(SearchMatch match,
			MessageSend messageSend, TypeReference[] typeArguments) {
		// TODO 自動生成されたメソッド・スタブ

	}

	public MethodBinding getMethodBinding(MethodPattern pattern) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	public IType lookupType(ReferenceBinding declaringClass) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	public IMethod createBinaryMethodHandle(IType type, char[] selector,
			char[][] parameterTypes) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	public IBinaryType getBinaryInfo(ClassFile classFile, IResource resource) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	public void reportBinaryMemberDeclaration(IResource resource,
			IMethod method, MethodBinding methodBinding, IBinaryType info, int i) {
		// TODO 自動生成されたメソッド・スタブ

	}

	public SearchParticipant getParticipant() {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}
}

