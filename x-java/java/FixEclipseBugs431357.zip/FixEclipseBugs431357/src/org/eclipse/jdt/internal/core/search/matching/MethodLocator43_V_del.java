// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   MethodLocator.java

package org.eclipse.jdt.internal.core.search.matching;

import java.io.PrintStream;
import java.util.HashMap;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jdt.core.*;
import org.eclipse.jdt.core.compiler.CharOperation;
import org.eclipse.jdt.core.search.*;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.util.SimpleSet;
import org.eclipse.jdt.internal.core.ClassFile;
import org.eclipse.jdt.internal.core.search.BasicSearchEngine;

// Referenced classes of package org.eclipse.jdt.internal.core.search.matching:
//            PatternLocator, DeclarationOfReferencedMethodsPattern, MethodPattern, SuperTypeNamesCollector, 
//            MatchLocator, MatchingNodeSet

public class MethodLocator43_V_del extends PatternLocator
{

    public MethodLocator43_V_del(MethodPattern pattern)
    {
        super(pattern);
        methodDeclarationsWithInvalidParam = new HashMap();
        this.pattern = pattern;
        isDeclarationOfReferencedMethodsPattern = this.pattern instanceof DeclarationOfReferencedMethodsPattern;
    }

    protected void clear()
    {
        methodDeclarationsWithInvalidParam = new HashMap();
    }

    protected int fineGrain()
    {
        return pattern.fineGrain;
    }

    private ReferenceBinding getMatchingSuper(ReferenceBinding binding)
    {
        if(binding == null)
            return null;
        ReferenceBinding superBinding = binding.superclass();
        int level = resolveLevelForType(pattern.declaringSimpleName, pattern.declaringQualification, superBinding);
        if(level != 0)
            return superBinding;
        if(!binding.isInterface() && !CharOperation.equals(binding.compoundName, TypeConstants.JAVA_LANG_OBJECT))
        {
            superBinding = getMatchingSuper(superBinding);
            if(superBinding != null)
                return superBinding;
        }
        ReferenceBinding interfaces[] = binding.superInterfaces();
        if(interfaces == null)
            return null;
        for(int i = 0; i < interfaces.length; i++)
        {
            level = resolveLevelForType(pattern.declaringSimpleName, pattern.declaringQualification, interfaces[i]);
            if(level != 0)
                return interfaces[i];
            superBinding = getMatchingSuper(interfaces[i]);
            if(superBinding != null)
                return superBinding;
        }

        return null;
    }

    private MethodBinding getMethodBinding(ReferenceBinding type, char methodName[], TypeBinding argumentTypes[])
    {
        MethodBinding methods[] = type.getMethods(methodName);
        MethodBinding method = null;
        int i = 0;
label0:
        for(int length = methods.length; i < length; i++)
        {
            method = methods[i];
            TypeBinding parameters[] = method.parameters;
            if(argumentTypes.length != parameters.length)
                continue;
            int j = 0;
            for(int l = parameters.length; j < l; j++)
                if(TypeBinding.notEquals(parameters[j].erasure(), argumentTypes[j].erasure()))
                    continue label0;

            return method;
        }

        return null;
    }

    public void initializePolymorphicSearch(MatchLocator locator)
    {
        long start = 0L;
        if(BasicSearchEngine.VERBOSE)
            start = System.currentTimeMillis();
        try
        {
            SuperTypeNamesCollector namesCollector = new SuperTypeNamesCollector(pattern, pattern.declaringSimpleName, pattern.declaringQualification, locator, pattern.declaringType, locator.progressMonitor);
            allSuperDeclaringTypeNames = namesCollector.collect();
            samePkgSuperDeclaringTypeNames = namesCollector.getSamePackageSuperTypeNames();
            matchLocator = locator;
        }
        catch(JavaModelException _ex) { }
        if(BasicSearchEngine.VERBOSE)
            System.out.println((new StringBuilder("Time to initialize polymorphic search: ")).append(System.currentTimeMillis() - start).toString());
    }

    private boolean isTypeInSuperDeclaringTypeNames(char typeName[][])
    {
        if(allSuperDeclaringTypeNames == null)
            return false;
        int length = allSuperDeclaringTypeNames.length;
        for(int i = 0; i < length; i++)
            if(CharOperation.equals(allSuperDeclaringTypeNames[i], typeName))
                return true;

        return false;
    }

    protected boolean isVirtualInvoke(MethodBinding method, MessageSend messageSend)
    {
        return !method.isStatic() && !method.isPrivate() && !messageSend.isSuperAccess() && (!method.isDefault() || pattern.focus == null || CharOperation.equals(pattern.declaringPackageName, method.declaringClass.qualifiedPackageName()));
    }

    public int match(ASTNode node, MatchingNodeSet nodeSet)
    {
        int declarationsLevel = 0;
        if(pattern.findReferences && (node instanceof ImportReference))
        {
            ImportReference importRef = (ImportReference)node;
            int length = importRef.tokens.length - 1;
            if(importRef.isStatic() && (importRef.bits & 0x20000) == 0 && matchesName(pattern.selector, importRef.tokens[length]))
            {
                char compoundName[][] = new char[length][];
                System.arraycopy(importRef.tokens, 0, compoundName, 0, length);
                char declaringType[] = CharOperation.concat(pattern.declaringQualification, pattern.declaringSimpleName, '.');
                if(matchesName(declaringType, CharOperation.concatWith(compoundName, '.')))
                    declarationsLevel = pattern.mustResolve ? 2 : 3;
            }
        }
        return nodeSet.addMatch(node, declarationsLevel);
    }

    public int match(LambdaExpression node, MatchingNodeSet nodeSet)
    {
        if(!pattern.findDeclarations)
            return 0;
        if(pattern.parameterSimpleNames != null && pattern.parameterSimpleNames.length != node.arguments().length)
        {
            return 0;
        } else
        {
            nodeSet.mustResolve = true;
            return nodeSet.addMatch(node, 2);
        }
    }

    public int match(MethodDeclaration node, MatchingNodeSet nodeSet)
    {
        if(!pattern.findDeclarations)
            return 0;
        if(!matchesName(pattern.selector, node.selector))
            return 0;
        boolean resolve = pattern.mustResolve;
        if(pattern.parameterSimpleNames != null)
        {
            int length = pattern.parameterSimpleNames.length;
            ASTNode args[] = node.arguments;
            int argsLength = args != null ? args.length : 0;
            if(length != argsLength)
                return 0;
            for(int i = 0; i < argsLength; i++)
                if(args != null && !matchesTypeReference(pattern.parameterSimpleNames[i], ((Argument)args[i]).type))
                    if(mayBeGeneric)
                    {
                        if(!pattern.mustResolve)
                        {
                            nodeSet.mustResolve = true;
                            resolve = true;
                        }
                        methodDeclarationsWithInvalidParam.put(node, null);
                    } else
                    {
                        return 0;
                    }

        }
        if(pattern.hasMethodArguments() && (node.typeParameters == null || node.typeParameters.length != pattern.methodArguments.length))
            return 0;
        else
            return nodeSet.addMatch(node, resolve ? 2 : 3);
    }

    public int match(MemberValuePair node, MatchingNodeSet nodeSet)
    {
        if(!pattern.findReferences)
            return 0;
        if(!matchesName(pattern.selector, node.name))
            return 0;
        else
            return nodeSet.addMatch(node, pattern.mustResolve ? 2 : 3);
    }

    public int match(MessageSend node, MatchingNodeSet nodeSet)
    {
        if(!pattern.findReferences)
            return 0;
        if(!matchesName(pattern.selector, node.selector))
            return 0;
        if(pattern.parameterSimpleNames != null && (!pattern.varargs || (node.bits & 0x8000) != 0))
        {
            int length = pattern.parameterSimpleNames.length;
            ASTNode args[] = node.arguments;
            int argsLength = args != null ? args.length : 0;
            if(length != argsLength)
                return 0;
        }
        return nodeSet.addMatch(node, pattern.mustResolve ? 2 : 3);
    }

    public int match(ReferenceExpression node, MatchingNodeSet nodeSet)
    {
        if(!pattern.findReferences)
            return 0;
        if(!matchesName(pattern.selector, node.selector))
        {
            return 0;
        } else
        {
            nodeSet.mustResolve = true;
            return nodeSet.addMatch(node, pattern.mustResolve ? 2 : 3);
        }
    }

    public int match(Annotation node, MatchingNodeSet nodeSet)
    {
        if(!pattern.findReferences)
            return 0;
        MemberValuePair pairs[] = node.memberValuePairs();
        if(pairs == null || pairs.length == 0)
            return 0;
        int length = pairs.length;
        MemberValuePair pair = null;
        for(int i = 0; i < length; i++)
        {
            pair = node.memberValuePairs()[i];
            if(matchesName(pattern.selector, pair.name))
            {
                ASTNode possibleNode = ((ASTNode) ((node instanceof SingleMemberAnnotation) ? ((ASTNode) (node)) : ((ASTNode) (pair))));
                return nodeSet.addMatch(possibleNode, pattern.mustResolve ? 2 : 3);
            }
        }

        return 0;
    }

    protected int matchContainer()
    {
        return !pattern.findReferences ? 2 : 15;
    }

    protected void matchLevelAndReportImportRef(ImportReference importRef, Binding binding, MatchLocator locator)
        throws CoreException
    {
        if(importRef.isStatic() && (binding instanceof MethodBinding))
            super.matchLevelAndReportImportRef(importRef, binding, locator);
    }

    protected int matchMethod(MethodBinding method, boolean skipImpossibleArg)
    {
        if(!matchesName(pattern.selector, method.selector))
            return 0;
        int level = 3;
        if(pattern.declaringSimpleName == null)
        {
            int newLevel = resolveLevelForType(pattern.returnSimpleName, pattern.returnQualification, method.returnType);
            if(level > newLevel)
            {
                if(newLevel == 0)
                    return 0;
                level = newLevel;
            }
        }
        int parameterCount = pattern.parameterSimpleNames != null ? pattern.parameterSimpleNames.length : -1;
        if(parameterCount > -1)
        {
            if(method.parameters == null)
                return 1;
            if(parameterCount != method.parameters.length)
                return 0;
            if(!method.isValidBinding() && ((ProblemMethodBinding)method).problemId() == 3)
                return 1;
            boolean foundTypeVariable = false;
            for(int i = 0; i < parameterCount; i++)
            {
                TypeBinding argType = method.parameters[i];
                int newLevel = 0;
// TODO: Fixed here
//                if(argType.isMemberType())
//                    newLevel = CharOperation.match(pattern.parameterSimpleNames[i], argType.sourceName(), isCaseSensitive) ? 3 : 0;
//                else
                    newLevel = resolveLevelForType(pattern.parameterSimpleNames[i], pattern.parameterQualifications[i], argType);
                if(level > newLevel)
                {
                    if(newLevel == 0)
                        if(skipImpossibleArg)
                            newLevel = level;
                        else
                        if(argType.isTypeVariable())
                        {
                            newLevel = level;
                            foundTypeVariable = true;
                        } else
                        {
                            return 0;
                        }
                    level = newLevel;
                }
            }

            if(foundTypeVariable)
            {
                if(!method.isStatic() && !method.isPrivate())
                {
                    MethodBinding focusMethodBinding = matchLocator.getMethodBinding(pattern);
                    if(focusMethodBinding != null && matchOverriddenMethod(focusMethodBinding.declaringClass, focusMethodBinding, method))
                        return 3;
                }
                return 0;
            }
        }
        return level;
    }

    private boolean matchOverriddenMethod(ReferenceBinding type, MethodBinding method, MethodBinding matchMethod)
    {
        if(type == null || pattern.selector == null)
            return false;
        if(!type.isInterface() && !CharOperation.equals(type.compoundName, TypeConstants.JAVA_LANG_OBJECT))
        {
            ReferenceBinding superClass = type.superclass();
            if(superClass.isParameterizedType())
            {
                MethodBinding methods[] = superClass.getMethods(pattern.selector);
                int length = methods.length;
                for(int i = 0; i < length; i++)
                    if(methods[i].areParametersEqual(method))
                        if(matchMethod == null)
                        {
                            if(methodParametersEqualsPattern(methods[i].original()))
                                return true;
                        } else
                        if(methods[i].original().areParametersEqual(matchMethod))
                            return true;

            }
            if(matchOverriddenMethod(superClass, method, matchMethod))
                return true;
        }
        ReferenceBinding interfaces[] = type.superInterfaces();
        if(interfaces == null)
            return false;
        int iLength = interfaces.length;
        for(int i = 0; i < iLength; i++)
        {
            if(interfaces[i].isParameterizedType())
            {
                MethodBinding methods[] = interfaces[i].getMethods(pattern.selector);
                int length = methods.length;
                for(int j = 0; j < length; j++)
                    if(methods[j].areParametersEqual(method))
                        if(matchMethod == null)
                        {
                            if(methodParametersEqualsPattern(methods[j].original()))
                                return true;
                        } else
                        if(methods[j].original().areParametersEqual(matchMethod))
                            return true;

            }
            if(matchOverriddenMethod(interfaces[i], method, matchMethod))
                return true;
        }

        return false;
    }

    protected void matchReportReference(ASTNode reference, IJavaElement element, Binding elementBinding, int accuracy, MatchLocator locator)
        throws CoreException
    {
        matchReportReference(reference, element, null, null, elementBinding, accuracy, locator);
    }

    protected void matchReportReference(ASTNode reference, IJavaElement element, IJavaElement localElement, IJavaElement otherElements[], Binding elementBinding, int accuracy, MatchLocator locator)
        throws CoreException
    {
        MethodBinding methodBinding = (reference instanceof MessageSend) ? ((MessageSend)reference).binding : (elementBinding instanceof MethodBinding) ? (MethodBinding)elementBinding : null;
        if(isDeclarationOfReferencedMethodsPattern)
        {
            if(methodBinding == null)
                return;
            if(accuracy != 0)
                return;
            DeclarationOfReferencedMethodsPattern declPattern;
            for(declPattern = (DeclarationOfReferencedMethodsPattern)pattern; element != null && !declPattern.enclosingElement.equals(element); element = element.getParent());
            if(element != null)
                reportDeclaration(methodBinding, locator, declPattern.knownMethods);
        } else
        {
            MethodReferenceMatch methodReferenceMatch = locator.newMethodReferenceMatch(element, elementBinding, accuracy, -1, -1, false, false, reference);
            methodReferenceMatch.setLocalElement(localElement);
            match = methodReferenceMatch;
            if(pattern.findReferences && (reference instanceof MessageSend))
            {
                IJavaElement focus = pattern.focus;
                if(focus != null && focus.getElementType() == 9 && methodBinding != null && methodBinding.declaringClass != null)
                {
                    boolean isPrivate = Flags.isPrivate(((IMethod)focus).getFlags());
                    if(isPrivate && !CharOperation.equals(methodBinding.declaringClass.sourceName, focus.getParent().getElementName().toCharArray()))
                        return;
                }
                matchReportReference((MessageSend)reference, locator, accuracy, ((MessageSend)reference).binding);
            } else
            {
                if(reference instanceof SingleMemberAnnotation)
                {
                    reference = ((SingleMemberAnnotation)reference).memberValuePairs()[0];
                    match.setImplicit(true);
                }
                int offset = reference.sourceStart;
                int length = (reference.sourceEnd - offset) + 1;
                match.setOffset(offset);
                match.setLength(length);
                locator.report(match);
            }
        }
    }

    void matchReportReference(MessageSend messageSend, MatchLocator locator, int accuracy, MethodBinding methodBinding)
        throws CoreException
    {
        boolean isParameterized = false;
        if(methodBinding instanceof ParameterizedGenericMethodBinding)
        {
            isParameterized = true;
            ParameterizedGenericMethodBinding parameterizedMethodBinding = (ParameterizedGenericMethodBinding)methodBinding;
            match.setRaw(parameterizedMethodBinding.isRaw);
            TypeBinding typeArguments[] = parameterizedMethodBinding.typeArguments;
            updateMatch(typeArguments, locator, pattern.methodArguments, pattern.hasMethodParameters());
            if(methodBinding.declaringClass.isParameterizedType() || methodBinding.declaringClass.isRawType())
            {
                ParameterizedTypeBinding parameterizedBinding = (ParameterizedTypeBinding)methodBinding.declaringClass;
                if((pattern.hasTypeArguments() || !pattern.hasMethodArguments()) && !parameterizedBinding.isParameterizedWithOwnVariables())
                    updateMatch(parameterizedBinding, pattern.getTypeArguments(), pattern.hasTypeParameters(), 0, locator);
            } else
            if(pattern.hasTypeArguments())
                match.setRule(16);
            if(match.getRule() != 0 && messageSend.resolvedType == null)
                match.setRule(16);
        } else
        if(methodBinding instanceof ParameterizedMethodBinding)
        {
            isParameterized = true;
            if(methodBinding.declaringClass.isParameterizedType() || methodBinding.declaringClass.isRawType())
            {
                ParameterizedTypeBinding parameterizedBinding = (ParameterizedTypeBinding)methodBinding.declaringClass;
                if(!parameterizedBinding.isParameterizedWithOwnVariables())
                {
                    if((accuracy & 0xc00) != 0)
                    {
                        ReferenceBinding refBinding = getMatchingSuper((ReferenceBinding)messageSend.actualReceiverType);
                        if(refBinding instanceof ParameterizedTypeBinding)
                            parameterizedBinding = (ParameterizedTypeBinding)refBinding;
                    }
                    if((accuracy & 0x200) == 0)
                        updateMatch(parameterizedBinding, pattern.getTypeArguments(), pattern.hasTypeParameters(), 0, locator);
                }
            } else
            if(pattern.hasTypeArguments())
                match.setRule(16);
            if(match.getRule() != 0 && messageSend.resolvedType == null)
                match.setRule(16);
        } else
        if(pattern.hasMethodArguments())
            match.setRule(16);
        if(match.getRule() == 0)
            return;
        boolean report = isErasureMatch && match.isErasure() || isEquivalentMatch && match.isEquivalent() || match.isExact();
        if(!report)
            return;
        int offset = (int)(messageSend.nameSourcePosition >>> 32);
        match.setOffset(offset);
        match.setLength((messageSend.sourceEnd - offset) + 1);
        if(isParameterized && pattern.hasMethodArguments())
            locator.reportAccurateParameterizedMethodReference(match, messageSend, messageSend.typeArguments);
        else
            locator.report(match);
    }

    private boolean methodParametersEqualsPattern(MethodBinding method)
    {
        TypeBinding methodParameters[] = method.parameters;
        int length = methodParameters.length;
        if(length != pattern.parameterSimpleNames.length)
            return false;
        for(int i = 0; i < length; i++)
        {
            char paramQualifiedName[] = qualifiedPattern(pattern.parameterSimpleNames[i], pattern.parameterQualifications[i]);
            if(!CharOperation.match(paramQualifiedName, methodParameters[i].readableName(), isCaseSensitive))
                return false;
        }

        return true;
    }

    public SearchMatch newDeclarationMatch(ASTNode reference, IJavaElement element, Binding elementBinding, int accuracy, int length, MatchLocator locator)
    {
        if(elementBinding != null)
        {
            MethodBinding methodBinding = (MethodBinding)elementBinding;
            if(methodDeclarationsWithInvalidParam.containsKey(reference))
            {
                Boolean report = (Boolean)methodDeclarationsWithInvalidParam.get(reference);
                if(report != null)
                    if(report.booleanValue())
                        return super.newDeclarationMatch(reference, element, elementBinding, accuracy, length, locator);
                    else
                        return null;
                if(matchOverriddenMethod(methodBinding.declaringClass, methodBinding, null))
                {
                    methodDeclarationsWithInvalidParam.put(reference, Boolean.TRUE);
                    return super.newDeclarationMatch(reference, element, elementBinding, accuracy, length, locator);
                }
                if(isTypeInSuperDeclaringTypeNames(methodBinding.declaringClass.compoundName))
                {
                    MethodBinding patternBinding = locator.getMethodBinding(pattern);
                    if(patternBinding != null && !matchOverriddenMethod(patternBinding.declaringClass, patternBinding, methodBinding))
                    {
                        methodDeclarationsWithInvalidParam.put(reference, Boolean.FALSE);
                        return null;
                    } else
                    {
                        methodDeclarationsWithInvalidParam.put(reference, Boolean.TRUE);
                        return super.newDeclarationMatch(reference, element, elementBinding, accuracy, length, locator);
                    }
                } else
                {
                    methodDeclarationsWithInvalidParam.put(reference, Boolean.FALSE);
                    return null;
                }
            }
        }
        return super.newDeclarationMatch(reference, element, elementBinding, accuracy, length, locator);
    }

    protected int referenceType()
    {
        return 9;
    }

    protected void reportDeclaration(MethodBinding methodBinding, MatchLocator locator, SimpleSet knownMethods)
        throws CoreException
    {
        ReferenceBinding declaringClass = methodBinding.declaringClass;
        IType type = locator.lookupType(declaringClass);
        if(type == null)
            return;
        if(type.isBinary())
        {
            IMethod method = null;
            TypeBinding parameters[] = methodBinding.original().parameters;
            int parameterLength = parameters.length;
            char parameterTypes[][] = new char[parameterLength][];
            for(int i = 0; i < parameterLength; i++)
            {
                char typeName[] = parameters[i].qualifiedSourceName();
                int j = 0;
                for(int dim = parameters[i].dimensions(); j < dim; j++)
                    typeName = CharOperation.concat(typeName, new char[] {
                        '[', ']'
                    });

                parameterTypes[i] = typeName;
            }

            method = locator.createBinaryMethodHandle(type, methodBinding.selector, parameterTypes);
            if(method == null || knownMethods.addIfNotIncluded(method) == null)
                return;
            IResource resource = type.getResource();
            if(resource == null)
                resource = type.getJavaProject().getProject();
            org.eclipse.jdt.internal.compiler.env.IBinaryType info = locator.getBinaryInfo((ClassFile)type.getClassFile(), resource);
            locator.reportBinaryMemberDeclaration(resource, method, methodBinding, info, 0);
            return;
        }
        IResource resource = type.getResource();
        if(declaringClass instanceof ParameterizedTypeBinding)
            declaringClass = ((ParameterizedTypeBinding)declaringClass).genericType();
        ClassScope scope = ((SourceTypeBinding)declaringClass).scope;
        if(scope != null)
        {
            TypeDeclaration typeDecl = scope.referenceContext;
            AbstractMethodDeclaration methodDecl = typeDecl.declarationOf(methodBinding.original());
            if(methodDecl != null)
            {
                String methodName = new String(methodBinding.selector);
                Argument arguments[] = methodDecl.arguments;
                int length = arguments != null ? arguments.length : 0;
                String parameterTypes[] = new String[length];
                for(int i = 0; i < length; i++)
                {
                    char typeName[][] = arguments[i].type.getParameterizedTypeName();
                    parameterTypes[i] = Signature.createTypeSignature(CharOperation.concatWith(typeName, '.'), false);
                }

                IMethod method = type.getMethod(methodName, parameterTypes);
                if(method == null || knownMethods.addIfNotIncluded(method) == null)
                    return;
                int offset = methodDecl.sourceStart;
                match = new MethodDeclarationMatch(method, 0, offset, (methodDecl.sourceEnd - offset) + 1, locator.getParticipant(), resource);
                locator.report(match);
            }
        }
    }

    public int resolveLevel(ASTNode possibleMatchingNode)
    {
        if(pattern.findReferences)
        {
            if(possibleMatchingNode instanceof MessageSend)
                return resolveLevel((MessageSend)possibleMatchingNode);
            if(possibleMatchingNode instanceof SingleMemberAnnotation)
            {
                SingleMemberAnnotation annotation = (SingleMemberAnnotation)possibleMatchingNode;
                return resolveLevel(((Binding) (annotation.memberValuePairs()[0].binding)));
            }
            if(possibleMatchingNode instanceof MemberValuePair)
            {
                MemberValuePair memberValuePair = (MemberValuePair)possibleMatchingNode;
                return resolveLevel(((Binding) (memberValuePair.binding)));
            }
            if(possibleMatchingNode instanceof ReferenceExpression)
                return resolveLevel((ReferenceExpression)possibleMatchingNode);
        }
        if(pattern.findDeclarations)
        {
            if(possibleMatchingNode instanceof MethodDeclaration)
                return resolveLevel(((Binding) (((MethodDeclaration)possibleMatchingNode).binding)));
            if(possibleMatchingNode instanceof LambdaExpression)
                return resolveLevel(((Binding) (((LambdaExpression)possibleMatchingNode).descriptor)));
        }
        return 0;
    }

    public int resolveLevel(Binding binding)
    {
        if(binding == null)
            return 1;
        if(!(binding instanceof MethodBinding))
            return 0;
        MethodBinding method = (MethodBinding)binding;
        boolean skipVerif = pattern.findDeclarations && mayBeGeneric;
        int methodLevel = matchMethod(method, skipVerif);
        if(methodLevel == 0)
        {
            if(method != method.original())
                methodLevel = matchMethod(method.original(), skipVerif);
            if(methodLevel == 0)
                return 0;
            method = method.original();
        }
        if(pattern.declaringSimpleName == null && pattern.declaringQualification == null)
            return methodLevel;
        boolean subType = !method.isStatic() && !method.isPrivate();
        if(subType && pattern.declaringQualification != null && method.declaringClass != null && method.declaringClass.fPackage != null)
            subType = CharOperation.compareWith(pattern.declaringQualification, method.declaringClass.fPackage.shortReadableName()) == 0;
        int declaringLevel = subType ? resolveLevelAsSubtype(pattern.declaringSimpleName, pattern.declaringQualification, method.declaringClass, method.selector, null, method.declaringClass.qualifiedPackageName(), method.isDefault()) : resolveLevelForType(pattern.declaringSimpleName, pattern.declaringQualification, method.declaringClass);
        return (methodLevel & 0xf) <= (declaringLevel & 0xf) ? methodLevel : declaringLevel;
    }

    protected int resolveLevel(MessageSend messageSend)
    {
        MethodBinding method = messageSend.binding;
        if(method == null)
            return 1;
        if(messageSend.resolvedType == null)
        {
            int argLength = messageSend.arguments != null ? messageSend.arguments.length : 0;
            return pattern.parameterSimpleNames != null && argLength != pattern.parameterSimpleNames.length ? 0 : 1;
        }
        int methodLevel = matchMethod(method, false);
        if(methodLevel == 0)
        {
            if(method != method.original())
                methodLevel = matchMethod(method.original(), false);
            if(methodLevel == 0)
                return 0;
            method = method.original();
        }
        if(pattern.declaringSimpleName == null && pattern.declaringQualification == null)
            return methodLevel;
        int declaringLevel;
        if(isVirtualInvoke(method, messageSend) && (messageSend.actualReceiverType instanceof ReferenceBinding))
        {
            ReferenceBinding methodReceiverType = (ReferenceBinding)messageSend.actualReceiverType;
            declaringLevel = resolveLevelAsSubtype(pattern.declaringSimpleName, pattern.declaringQualification, methodReceiverType, method.selector, method.parameters, methodReceiverType.qualifiedPackageName(), method.isDefault());
            if(declaringLevel == 0)
                if(method.declaringClass == null || allSuperDeclaringTypeNames == null)
                {
                    declaringLevel = 1;
                } else
                {
                    char superTypeNames[][][] = !method.isDefault() || pattern.focus != null ? allSuperDeclaringTypeNames : samePkgSuperDeclaringTypeNames;
                    if(superTypeNames != null && resolveLevelAsSuperInvocation(methodReceiverType, method.parameters, superTypeNames, true))
                        declaringLevel = methodLevel | 0x200;
                }
            if((declaringLevel & 0xfffffff0) != 0)
                return declaringLevel;
        } else
        {
            declaringLevel = resolveLevelForType(pattern.declaringSimpleName, pattern.declaringQualification, method.declaringClass);
        }
        return (methodLevel & 0xf) <= (declaringLevel & 0xf) ? methodLevel : declaringLevel;
    }

    protected int resolveLevel(ReferenceExpression referenceExpression)
    {
        MethodBinding method = referenceExpression.getMethodBinding();
        if(method == null || !method.isValidBinding())
            return 1;
        int methodLevel = matchMethod(method, false);
        if(methodLevel == 0)
        {
            if(method != method.original())
                methodLevel = matchMethod(method.original(), false);
            if(methodLevel == 0)
                return 0;
            method = method.original();
        }
        if(pattern.declaringSimpleName == null && pattern.declaringQualification == null)
        {
            return methodLevel;
        } else
        {
            int declaringLevel = resolveLevelForType(pattern.declaringSimpleName, pattern.declaringQualification, method.declaringClass);
            return (methodLevel & 0xf) <= (declaringLevel & 0xf) ? methodLevel : declaringLevel;
        }
    }

    protected int resolveLevelAsSubtype(char simplePattern[], char qualifiedPattern[], ReferenceBinding type, char methodName[], TypeBinding argumentTypes[], char packageName[], boolean isDefault)
    {
        if(type == null)
            return 1;
        int level = resolveLevelForType(simplePattern, qualifiedPattern, type);
        if(level != 0)
        {
            if(isDefault && !CharOperation.equals(packageName, type.qualifiedPackageName()))
                return 0;
            MethodBinding method = argumentTypes != null ? getMethodBinding(type, methodName, argumentTypes) : null;
            if((method != null && !method.isAbstract() || !type.isAbstract()) && !type.isInterface())
                level |= 0x800;
            return level;
        }
        if(!type.isInterface() && !CharOperation.equals(type.compoundName, TypeConstants.JAVA_LANG_OBJECT))
        {
            level = resolveLevelAsSubtype(simplePattern, qualifiedPattern, type.superclass(), methodName, argumentTypes, packageName, isDefault);
            if(level != 0)
            {
                if(argumentTypes != null)
                {
                    MethodBinding method = getMethodBinding(type, methodName, argumentTypes);
                    if(method != null)
                    {
                        if((level & 0x800) != 0)
                            return 0;
                        if(!method.isAbstract() && !type.isInterface())
                            level |= 0x800;
                    }
                }
                return level | 0x400;
            }
        }
        ReferenceBinding interfaces[] = type.superInterfaces();
        if(interfaces == null)
            return 1;
        for(int i = 0; i < interfaces.length; i++)
        {
            level = resolveLevelAsSubtype(simplePattern, qualifiedPattern, interfaces[i], methodName, null, packageName, isDefault);
            if(level != 0)
            {
                if(!type.isAbstract() && !type.isInterface())
                    level |= 0x800;
                return level | 0x400;
            }
        }

        return 0;
    }

    private boolean resolveLevelAsSuperInvocation(ReferenceBinding type, TypeBinding argumentTypes[], char superTypeNames[][][], boolean methodAlreadyVerified)
    {
        char compoundName[][] = type.compoundName;
        int i = 0;
        for(int max = superTypeNames.length; i < max; i++)
        {
            if(!CharOperation.equals(superTypeNames[i], compoundName))
                continue;
            if(methodAlreadyVerified)
                return true;
            MethodBinding methods[] = type.getMethods(pattern.selector);
            int j = 0;
            for(int length = methods.length; j < length; j++)
            {
                MethodBinding method = methods[j];
                TypeBinding parameters[] = method.parameters;
                if(argumentTypes.length == parameters.length)
                {
                    boolean found = true;
                    int k = 0;
                    for(int l = parameters.length; k < l; k++)
                    {
                        if(!TypeBinding.notEquals(parameters[k].erasure(), argumentTypes[k].erasure()))
                            continue;
                        found = false;
                        break;
                    }

                    if(found)
                        return true;
                }
            }

            break;
        }

        if(type.isInterface())
        {
            ReferenceBinding interfaces[] = type.superInterfaces();
            if(interfaces == null)
                return false;
            for(int j = 0; j < interfaces.length; j++)
                if(resolveLevelAsSuperInvocation(interfaces[j], argumentTypes, superTypeNames, false))
                    return true;

        }
        return false;
    }

    public String toString()
    {
        return (new StringBuilder("Locator for ")).append(pattern.toString()).toString();
    }

    protected MethodPattern pattern;
    protected boolean isDeclarationOfReferencedMethodsPattern;
    public char allSuperDeclaringTypeNames[][][];
    private char samePkgSuperDeclaringTypeNames[][][];
    private MatchLocator matchLocator;
    private HashMap methodDeclarationsWithInvalidParam;
}
