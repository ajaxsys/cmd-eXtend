package test;

public class Test {
	public static void foo() {
		Foo.InnerKey key = new Foo.InnerKey();
		getInstance().query(key);
	}

	public static void bar() {
		Bar.InnerKey key = new Bar.InnerKey();
		getInstance().query(key);
	}

	public static MyIF getInstance() {
		// TODO code to get instance
		return null;
	}

}

interface MyIF {
	public void query(Foo.InnerKey key); // Method to open call hierarchy

	public void query(Bar.InnerKey key);
}

class Foo {
	static class InnerKey {
	}
}

class Bar {
	static class InnerKey {
	}
}