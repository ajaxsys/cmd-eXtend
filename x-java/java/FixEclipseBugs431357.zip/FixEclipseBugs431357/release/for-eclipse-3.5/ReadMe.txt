use del ver:
org.eclipse.jdt.internal.core.search.matching.MethodLocator35_V_del