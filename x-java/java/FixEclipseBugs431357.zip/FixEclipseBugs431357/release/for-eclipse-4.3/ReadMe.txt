use patch ver:
org.eclipse.jdt.internal.core.search.matching.MethodLocator43