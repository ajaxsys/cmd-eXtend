A patch class for eclipse bugs 431357.
Target class: 
	org.eclipse.jdt.internal.core.search.matching.MethodLocator

https://bugs.eclipse.org/bugs/show_bug.cgi?id=431357





Patch:

diff --git a/org.eclipse.jdt.core.tests.model/src/org/eclipse/jdt/core/tests/model/JavaSearchBugs8Tests.java b/org.eclipse.jdt.core.tests.model/src/org/eclipse/jdt/core/tests/model/JavaSearchBugs8Tests.java
index 04d010d..f76622f 100644
--- a/org.eclipse.jdt.core.tests.model/src/org/eclipse/jdt/core/tests/model/JavaSearchBugs8Tests.java
+++ b/org.eclipse.jdt.core.tests.model/src/org/eclipse/jdt/core/tests/model/JavaSearchBugs8Tests.java
@@ -4425,6 +4425,55 @@
 this.resultCollector,
 null);
 }
+/** @bug 431357
+ * [1.8][compiler] NPE when creating LambdaMethod element for lambda expressions with errors
+ * @see "https://bugs.eclipse.org/bugs/show_bug.cgi?id=431357"
+ */
+public void testBug431357() throws CoreException {
+	this.workingCopies = new ICompilationUnit[1];
+	this.workingCopies[0] = getWorkingCopy("/JavaSearchBugs/src/X.java",
+			"interface I { \n" +
+			"    public void query(Foo.InnerKey key);// Search result of method query(Foo.InnerKey) returns the method query(Bar.InnerKey) too \n" +
+			"    public void query(Bar.InnerKey key);\n" +
+			"}\n" +
+			"\n" +
+			"class Foo { \n" +
+			"    static class InnerKey  {}\n" +
+			"}\n" +
+			"class Bar {\n" +
+			"    static class InnerKey {}\n" +
+			"}\n" +
+			"\n" +
+			"class X {\n" +
+			"	public static void foo(I i, Foo.InnerKey key) {\n" +
+			"		i.query(key);\n" +
+			"	}\n" +
+			"	public static void bar(I i, Bar.InnerKey key) {\n" +
+			"		i.query(key);\n" +
+			"	}\n" +
+			"	public static I getInstance() {\n" +
+			"		return null;\n" +
+			"	}\n" +
+			"}\n"
+	);
+
+	String str = this.workingCopies[0].getSource();
+	String selection = "query";
+	int start = str.indexOf(selection);
+	int length = selection.length();
+
+	IJavaElement[] elements = this.workingCopies[0].codeSelect(start, length);
+	MethodPattern pattern = (MethodPattern) SearchPattern.createPattern(elements[0], REFERENCES, EXACT_RULE | ERASURE_RULE);
+
+	new SearchEngine(this.workingCopies).search(pattern,
+			new SearchParticipant[] {SearchEngine.getDefaultSearchParticipant()},
+			getJavaSearchWorkingCopiesScope(),
+			this.resultCollector,
+			null);
+	assertSearchResults(
+			"src/X.java void X.foo(I, Foo.InnerKey) [query(key)] EXACT_MATCH"
+	);
+}
 // Add new tests in JavaSearchBugs8Tests
 }
 
diff --git a/org.eclipse.jdt.core/search/org/eclipse/jdt/internal/core/search/matching/MethodLocator.java b/org.eclipse.jdt.core/search/org/eclipse/jdt/internal/core/search/matching/MethodLocator.java
index 61bc89c..5b82f7b 100644
--- a/org.eclipse.jdt.core/search/org/eclipse/jdt/internal/core/search/matching/MethodLocator.java
+++ b/org.eclipse.jdt.core/search/org/eclipse/jdt/internal/core/search/matching/MethodLocator.java
@@ -314,10 +314,21 @@
 			TypeBinding argType = method.parameters[i];
 			int newLevel = IMPOSSIBLE_MATCH;
 			if (argType.isMemberType()) {
-				// only compare source name for member type (bug 41018)
-				newLevel = CharOperation.match(this.pattern.parameterSimpleNames[i], argType.sourceName(), this.isCaseSensitive)
-					? ACCURATE_MATCH
-					: IMPOSSIBLE_MATCH;
+				boolean foundLevel = false;
+				MethodBinding focusMethodBinding = this.matchLocator.getMethodBinding(this.pattern);
+				if (focusMethodBinding != null) {// textual comparison insufficient
+					TypeBinding[] parameters = focusMethodBinding.parameters;
+					if (parameters.length >= parameterCount) {
+						newLevel = argType.isCompatibleWith((parameters[i])) ? ACCURATE_MATCH : IMPOSSIBLE_MATCH;
+						foundLevel = true;
+					}
+				}
+				if (!foundLevel) { // a safety net
+					// only compare source name for member type (bug 41018)
+					newLevel = CharOperation.match(this.pattern.parameterSimpleNames[i], argType.sourceName(), this.isCaseSensitive)
+							? ACCURATE_MATCH
+							: IMPOSSIBLE_MATCH;
+				}
 			} else {
 				// TODO (frederic) use this call to refine accuracy on parameter types
 //				 newLevel = resolveLevelForType(this.pattern.parameterSimpleNames[i], this.pattern.parameterQualifications[i], this.pattern.parametersTypeArguments[i], 0, argType);