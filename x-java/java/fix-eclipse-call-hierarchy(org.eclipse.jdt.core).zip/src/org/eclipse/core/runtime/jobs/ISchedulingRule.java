package org.eclipse.core.runtime.jobs;

public interface ISchedulingRule {

}
