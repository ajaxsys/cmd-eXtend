package org.eclipse.core.runtime;

public class IProgressMonitor {

}
