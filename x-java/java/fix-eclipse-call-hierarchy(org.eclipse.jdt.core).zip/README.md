Fixed class file path:

origin\org\eclipse\jdt\internal\core\search\matching\MethodLocator.class

Remove the if statement:

    if (argType.isMemberType())

, that was introduced to fix Bug 41018(https://bugs.eclipse.org/bugs/show_bug.cgi?id=41018).

Need add 2 eclispe jars from eclipse/plugins folder:
eclipse\plugins\org.eclipse.jdt.core_*.jar
eclipse\plugins\org.eclipse.core.resources_*.jar
